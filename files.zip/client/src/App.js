import React, { useState, useEffect, useRef } from "react";

// Demo data for puppies (in real app: fetch from backend)
const puppies = [
  {
    id: 1,
    name: "Buddy",
    age: "1.8 years",
    img: "https://placedog.net/400/300?id=1",
    price: 3000,
  },
  {
    id: 2,
    name: "Bella",
    age: "2.1 years",
    img: "https://placedog.net/400/300?id=2",
    price: 2900,
  },
  // Add more puppies...
];

// Payment methods
const paymentMethods = ["PayPal", "Chime", "MasterCard Gift Card"];

// Utility to get user location (city/country for demo)
const getLocation = async () => {
  return new Promise((resolve) => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(async (pos) => {
        const { latitude, longitude } = pos.coords;
        // Use a geocoding API for real location lookup
        resolve(`Lat: ${latitude.toFixed(3)}, Lon: ${longitude.toFixed(3)}`);
      }, () => resolve("Location unavailable"));
    } else {
      resolve("Geolocation not supported");
    }
  });
};

function App() {
  // Cart/Crate
  const [crate, setCrate] = useState([]);
  // Chat
  const [showChat, setShowChat] = useState(false);
  const [chatHistory, setChatHistory] = useState([]);
  const [message, setMessage] = useState("");
  // Payment
  const [selectedPayment, setSelectedPayment] = useState(paymentMethods[0]);
  // Image upload
  const [uploadedImage, setUploadedImage] = useState(null);

  // Effect: load chat history (simulate from backend/localStorage)
  useEffect(() => {
    const local = window.localStorage.getItem("chatHistory");
    if (local) setChatHistory(JSON.parse(local));
  }, []);

  // Save chat history to localStorage
  useEffect(() => {
    window.localStorage.setItem("chatHistory", JSON.stringify(chatHistory));
  }, [chatHistory]);

  // Add puppy to crate
  const addToCrate = (puppy) => {
    if (!crate.find((p) => p.id === puppy.id)) {
      setCrate([...crate, puppy]);
    }
  };

  // Remove puppy from crate
  const removeFromCrate = (id) => {
    setCrate(crate.filter((p) => p.id !== id));
  };

  // Handle sending message to breeder/admin
  const sendMessage = async () => {
    const loc = await getLocation();
    const now = new Date().toLocaleString();
    const msg = {
      text: message,
      time: now,
      location: loc,
      image: uploadedImage,
      puppy: crate,
      payment: selectedPayment,
      from: "me",
    };
    setChatHistory([...chatHistory, msg]);
    setMessage("");

    // Auto-message on first contact
    if (chatHistory.length === 0) {
      const autoMsg = {
        text: `Hello Breeder/Admin, I want to buy: ${crate.map(p => p.name).join(", ")} via ${selectedPayment}. How will delivery and payment work?`,
        time: now,
        location: loc,
        puppy: crate,
        payment: selectedPayment,
        from: "system",
      };
      setChatHistory((prev) => [...prev, autoMsg]);
    }
    // In real app: send to backend via API
  };

  // Handle image upload
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setUploadedImage(ev.target.result);
      reader.readAsDataURL(file);
    }
  };

  // Toggle chat window
  const toggleChat = () => setShowChat(!showChat);

  return (
    <div style={{ fontFamily: "Arial, sans-serif", minHeight: "100vh", background: "#f5f5f5" }}>
      <header style={{ background: "#2c3e50", color: "#fff", padding: 20, textAlign: "center" }}>
        <h1>DarkDynastyK9s</h1>
        <p>Premium Puppies – Vaccinated, Insured, Healthy</p>
      </header>

      {/* Puppy list */}
      <div style={{ display: "flex", flexWrap: "wrap", gap: 20, justifyContent: "center", padding: 20 }}>
        {puppies.map((puppy) => (
          <div key={puppy.id} style={{ background: "#fff", borderRadius: 8, boxShadow: "0 4px 8px #0001", width: 250, padding: 15 }}>
            <img src={puppy.img} alt={puppy.name} style={{ width: "100%", borderRadius: 8 }} />
            <div style={{ fontWeight: "bold", margin: "10px 0 5px" }}>{puppy.name}</div>
            <div>Age: {puppy.age}</div>
            <div>Vaccinated: Yes</div>
            <div>Insured: Yes</div>
            <div>Healthy: 100%</div>
            <div>Price: ${puppy.price} (Negotiable)</div>
            <div>Delivery: Free in US, Half Price International</div>
            <button style={{ marginTop: 10 }} onClick={() => addToCrate(puppy)}>Add to Crate</button>
          </div>
        ))}
      </div>

      {/* Crate */}
      <div style={{ background: "#fff", margin: "20px auto", padding: 15, borderRadius: 8, width: "90%", maxWidth: 700, boxShadow: "0 4px 8px #0001" }}>
        <h3>Your Crate</h3>
        {crate.length === 0 ? (
          <div>No puppies added yet.</div>
        ) : (
          crate.map((puppy) => (
            <div key={puppy.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #eee", padding: "5px 0" }}>
              <span>{puppy.name} (${puppy.price})</span>
              <button onClick={() => removeFromCrate(puppy.id)}>Remove</button>
            </div>
          ))
        )}
        {/* Payment methods */}
        {crate.length > 0 && (
          <div style={{ marginTop: 15 }}>
            <div><b>Choose Payment Method:</b></div>
            {paymentMethods.map((m) => (
              <label key={m} style={{ marginRight: 12 }}>
                <input type="radio" checked={selectedPayment === m} onChange={() => setSelectedPayment(m)} /> {m}
              </label>
            ))}
            <div style={{ marginTop: 10 }}>
              <button onClick={toggleChat}>Message Breeder</button>
            </div>
          </div>
        )}
      </div>

      {/* Chat icon (always at top right) */}
      <div onClick={toggleChat} style={{
        position: "fixed", top: 20, right: 20, cursor: "pointer", zIndex: 999,
        background: "#3498db", color: "#fff", padding: 12, borderRadius: "50%", fontSize: 24, boxShadow: "0 4px 8px #0002"
      }}>
        💬
      </div>

      {/* Chat window/modal */}
      {showChat && (
        <div style={{
          position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh",
          background: "rgba(0,0,0,.4)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center"
        }}>
          <div style={{ background: "#fff", borderRadius: 8, maxWidth: 400, width: "95%", padding: 20, position: "relative" }}>
            <button onClick={toggleChat} style={{
              position: "absolute", right: 10, top: 10, background: "none", border: "none", fontSize: 20, cursor: "pointer"
            }}>×</button>
            <h3>Chat with Breeder / Admin</h3>
            <div style={{ maxHeight: 250, overflowY: "auto", marginBottom: 10, border: "1px solid #eee", padding: 8, borderRadius: 4 }}>
              {chatHistory.map((msg, i) => (
                <div key={i} style={{ marginBottom: 8, textAlign: msg.from === "me" ? "right" : "left" }}>
                  <div style={{ fontSize: 13, color: "#888" }}>{msg.time} ({msg.location})</div>
                  <div style={{
                    display: "inline-block",
                    background: msg.from === "me" ? "#e0f7fa" : "#f9fbe7",
                    padding: "7px 12px",
                    borderRadius: 15,
                    margin: "2px 0"
                  }}>
                    {msg.text}
                    {msg.image && <div><img src={msg.image} alt="upload" style={{ width: 70, borderRadius: 6, marginTop: 4 }} /></div>}
                  </div>
                </div>
              ))}
            </div>
            <input
              type="text"
              placeholder="Type your message..."
              value={message}
              onChange={e => setMessage(e.target.value)}
              style={{ width: "100%", marginBottom: 8 }}
            />
            <input type="file" accept="image/*" onChange={handleImageUpload} style={{ marginBottom: 8 }} />
            <button onClick={sendMessage} disabled={!message && !uploadedImage} style={{ width: "100%" }}>
              Send
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;